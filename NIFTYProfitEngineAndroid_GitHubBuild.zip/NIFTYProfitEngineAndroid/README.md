# NIFTY Profit Engine V45 — Android

This project packages the existing NIFTY Profit Engine V45 HTML/JavaScript engine inside an Android WebView, with a mobile-first UI.

## Build the APK without Android Studio

The project includes a GitHub Actions workflow at:

`.github/workflows/build-apk.yml`

### Steps

1. Create/sign in to a GitHub account.
2. Create a new repository, for example `NIFTYProfitEngine`.
3. Upload **all contents of this project folder** to the repository, including the `.github` folder.
4. Open the repository's **Actions** tab.
5. Select **Build NIFTY Profit Engine APK**.
6. Choose **Run workflow**.
7. Wait for the green checkmark.
8. Open the completed workflow run and download the artifact named:
   `NIFTY-Profit-Engine-V45-debug`
9. Extract the downloaded artifact to get `app-debug.apk`.
10. Transfer `app-debug.apk` to your Android phone and open it.
11. If Android asks, allow your file manager/browser to **install unknown apps**, then install it.

## Build locally

Open this folder in Android Studio and build the `app` module. The project uses Android Gradle Plugin 8.7.3, compile/target SDK 35, and minimum SDK 23.

## Important

This app is a WebView wrapper around the supplied V45 HTML engine. It does not add a real-order/trading API. Paper trading remains paper trading. The existing Angel One live market-data connection in the supplied engine is retained.
